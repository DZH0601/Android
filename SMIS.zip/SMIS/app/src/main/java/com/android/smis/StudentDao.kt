package com.android.smis

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase

class StudentDao(context: Context) {
    val dbHelper = DBHelper(context, "stu.db", 1)
    lateinit var db:SQLiteDatabase

    fun openDB() {
        db = dbHelper.writableDatabase
    }

    fun closeDB() {
        if (db != null) dbHelper.close()
    }
    // 插入学生
    fun insertStudent(stu: Student) {
        val values = ContentValues().apply {
            put("id", stu.id)
            put("name", stu.name)
            put("age", stu.age)
        }
        db.insert("Student", null, values)
    }
    // 删除学生
    fun deleteStudent(stu: Student) {
        db.delete("Student", "id = ?", arrayOf(stu.id))
    }
    // 更新学生
    fun updateStudent(stu: Student) {
        val values = ContentValues()
        values.put("name", stu.name)
        values.put("age", stu.age)
        db.update("Student", values, "id = ?", arrayOf(stu.id))
    }
    // 查询所有学生
    fun queryAllStudent():ArrayList<Student> {
        val cursor = db.query("Student", null, null, null, null, null, null)
        val stuList = ArrayList<Student>()
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getString(cursor.getColumnIndex("id"))
                val name = cursor.getString(cursor.getColumnIndex("name"))
                val age = cursor.getString(cursor.getColumnIndex("age"))
                val stu = Student(id, name, age)
                stuList.add(stu)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return stuList
    }
    // 查询指定学号的学生
    fun queryById(stuId:String):Student? {
        val cursor = db.query("Student", null, null, null, null, null, null)
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getString(cursor.getColumnIndex("id"))
                // 如果该学生存在则返回对象
                if (id == stuId) {
                    val name = cursor.getString(cursor.getColumnIndex("name"))
                    val age = cursor.getString(cursor.getColumnIndex("age"))
                    val stu = Student(id, name, age)
                    cursor.close()
                    return stu
                }
            } while (cursor.moveToNext())
        }
        cursor.close()
        return null
    }

}