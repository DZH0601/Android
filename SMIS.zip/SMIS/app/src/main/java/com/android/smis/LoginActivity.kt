package com.android.smis

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.android.smis.databinding.ActivityLoginBinding
import com.android.smis.databinding.ActivityMainBinding

class LoginActivity : AppCompatActivity() {
    lateinit var sharedPreferences:SharedPreferences
    lateinit var binding:ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        sharedPreferences = getSharedPreferences("data", Context.MODE_PRIVATE)
        var editor = sharedPreferences.edit()
        // 得到之前的使用次数，然后每次打开app都加1
        var count = sharedPreferences.getString("count", "0");
        binding.tvCount.text = (count!!.toInt() + 1).toString()
        // 保存键值对到sharedpreferences中
        editor.putString("count", (count!!.toInt() + 1).toString())
        editor.apply()
        binding.btnLogin.setOnClickListener{
            editor.putString("account", binding.etAccount.toString().trim())
            editor.putString("password", binding.etPassword.toString().trim())
            editor.apply()
            Toast.makeText(this, "登录成功！", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}