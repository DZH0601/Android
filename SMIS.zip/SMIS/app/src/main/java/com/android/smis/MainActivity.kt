package com.android.smis

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import com.android.smis.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), View.OnClickListener {
    lateinit var binding:ActivityMainBinding
    val studentDao = StudentDao(this)
    var studentList = ArrayList<Student>()
    lateinit var adapter:StudentAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        studentDao.openDB()
        initView()
    }

    fun initView() {
        binding.btnInsert.setOnClickListener(this)
        binding.btnDelete.setOnClickListener(this)
        binding.btnUpdate.setOnClickListener(this)
        binding.btnQuery.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        var stuId = binding.etId.text.toString()
        var stuName = binding.etName.text.toString()
        var stuAge = binding.etAge.text.toString()
        var stu = Student(stuId, stuName, stuAge)
        var flag = (studentDao.queryById(stuId) != null)
        when(p0?.id) {
            R.id.btn_insert->{
                if (flag) {
                    Toast.makeText(this, "学生已存在，无法添加", Toast.LENGTH_SHORT).show()
                } else {
                    studentDao.insertStudent(stu)
                    Toast.makeText(this, "添加成功！", Toast.LENGTH_SHORT).show()
                }
            }
            R.id.btn_delete->{
                if (flag) {
                    studentDao.deleteStudent(stu)
                    Toast.makeText(this, "删除成功！", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "该学生不存在，无法删除", Toast.LENGTH_SHORT).show()
                }
            }
            R.id.btn_update->{
                if (flag) {
                    studentDao.updateStudent(stu)
                    Toast.makeText(this, "修改成功！", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "该学生不存在，无法修改", Toast.LENGTH_SHORT).show()
                }
            }
            R.id.btn_query->{
                if (flag) {// 如果存在则补全信息
                    binding.etAge.setText(studentDao.queryById(stuId)?.age)
                    binding.etName.setText(studentDao.queryById(stuId)?.name)
                    Toast.makeText(this, "查询到该学生信息", Toast.LENGTH_SHORT).show()
                } else {// 不存在则显示所有学生信息
                    studentList = studentDao.queryAllStudent()
                    adapter = StudentAdapter(this, R.layout.item_student, studentList)
                    binding.lvStu.adapter = adapter
                    Toast.makeText(this, "查询所有学生信息", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}