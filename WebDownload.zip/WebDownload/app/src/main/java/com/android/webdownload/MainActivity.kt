package com.android.webdownload

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.*
import androidx.appcompat.app.AppCompatActivity
import android.util.Log
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.android.webdownload.databinding.ActivityMainBinding

import java.io.File
import java.io.FileOutputStream
import java.lang.Exception
import java.lang.ref.WeakReference
import java.net.HttpURLConnection
import java.net.URL
import java.util.jar.Manifest

class MainActivity : AppCompatActivity() {
    private var bitmap:Bitmap? = null
    private lateinit var binding: ActivityMainBinding
    private val url:String = "http://e.hiphotos.baidu.com/image/pic/item/4e4a20a4462309f7e41f5cfe760e0cf3d6cad6ee.jpg"
    private val saveDirs:String = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()
    private val savePath:String = saveDirs + File.separator + System.currentTimeMillis() + ".png"
    val handler:Handler = Handler {
        when(it.what) {
            0-> {
                for (i in 0..100) binding.progress.progress = i
            }
            1 -> {
                binding.ivShow.background = null
                binding.ivShow.setImageBitmap(bitmap)
                saveImage(bitmap)
                binding.tvShow.text = "下载成功！"
                Toast.makeText(this, "下载已完成", Toast.LENGTH_SHORT).show()
            }
            else -> Log.d("Test", "else")
        }
        false
    };
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
        binding.btnDownload.setOnClickListener({
            try {
                thread1.start()
            } catch (e:Exception) {
                e.printStackTrace()
            }
        })
        binding.btnStop.setOnClickListener({
            if (thread1.isAlive) {
                thread1.interrupt()
                Toast.makeText(this, "interrupt()", Toast.LENGTH_SHORT).show()
            }
            if (!thread1.isAlive) {
                binding.tvShow.text = "下载终止！"
                Toast.makeText(this, "下载已终止", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when(requestCode) {
            1-> {
                if (grantResults.isNotEmpty() &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "你可以正常使用app", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "你拒绝了权限，无法正常保存图片", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // 创建下载图片的子线程，准备下载前和下载完成后都发送message
    val thread1 = Thread {
        val message = Message()
        message.what = 0
        handler.sendMessage(message)
        bitmap = getImage(url)
        val message2 = Message()
        message2.what = 1
        handler.sendMessage(message2)
    }

    // 下载图片，转为位图
    fun getImage(imageUrl: String): Bitmap? {
        var myBitmap:Bitmap? = null
        var connection:HttpURLConnection
        try {
            var url = URL(imageUrl)
            connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 8000
            connection.doInput = true
            connection.useCaches = false
            val myInput = connection.inputStream
            myBitmap = BitmapFactory.decodeStream(myInput)
            myInput.close()
        } catch (e:Exception) {
            e.printStackTrace()
        }
        return myBitmap;
    }

    // 保存位图到本地路径
    private fun saveImage(bitmap:Bitmap?) {
        var file = File(saveDirs)
        // 如果文件不存在则创建目录
        if (!file.exists()) {
            if (file.mkdir()) {
                Log.d("test", "mkdir")
            } else {
                Log.d("test", "failed")
            }
        }
        try {
            val fileOutputStream = FileOutputStream(savePath)
            bitmap?.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream)
            fileOutputStream.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}